jQuery(document).ready(function($){
    $('.q-tooltip').qtip({
        show: {
            effect: function() {
                $(this).fadeTo(500, 1);
            }
        },
        hide: {
            effect: function() {
                $(this).slideUp();
            }
        }
     });
 });