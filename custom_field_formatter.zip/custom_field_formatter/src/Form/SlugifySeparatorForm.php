<?php
namespace Drupal\custom_field_formatter\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Configure slufigy separator settings.
 */
class SlugifySeparatorForm extends ConfigFormBase {
  /** 
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'slugify_separator_settings';
  }

  /** 
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'custom_field_formatter.settings',
    ];
  }

  /** 
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('custom_field_formatter.settings');

    $form['slugify'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Slugify Separator'),
      '#default_value' => $config->get('slugify'),
      '#required' => true,
    );  

    return parent::buildForm($form, $form_state);
    
  }

  /** 
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Retrieve the configuration
    $this->config('custom_field_formatter.settings')
      ->set('slugify', $form_state->getValue('slugify'))
      ->save();
    parent::submitForm($form, $form_state);
  }
}