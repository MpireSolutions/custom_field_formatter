<?php

/**
 * @file
 * 
 * Contains \Drupal\custom_field_formatter\Plugin\Field\FieldFormatter\ToolTip.
 */

namespace Drupal\custom_field_formatter\Plugin\Field\FieldFormatter;

use Drupal\Core\Field\FormatterBase;
use Drupal\Core\Field\FieldItemListInterface;

/**
 * Plugin implementation of the 'ToolTip' formatter.
 *
 * @FieldFormatter(
 *   id = "customfield_tooltip",
 *   label = @Translation("ToolTip Formatter"),
 *   field_types = {
 *     "text",
 *     "text_long",
 *     "text_with_summary"
 *   }
 * )
 */
class ToolTip extends FormatterBase { 
/**
* {@inheritdoc}
*/    
    private function ToolTip($data) {    
        
    }

/**
* {@inheritdoc}
*/
    public function viewElements(FieldItemListInterface $items, $langcode) {
        $element = array();

        foreach ($items as $delta => $item) {
          // Render each element as markup.
          $element[$delta] = array(
            '#theme' => 'tooltip_link_formatter',
            '#text' => $item->value,
          );
        }

        return $element;
   }
}