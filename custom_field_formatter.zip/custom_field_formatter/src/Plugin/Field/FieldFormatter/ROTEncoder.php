<?php

/**
 * @file
 * 
 * Contains \Drupal\custom_field_formatter\Plugin\Field\FieldFormatter\ROTEncoder.
 */

namespace Drupal\custom_field_formatter\Plugin\Field\FieldFormatter;

use Drupal\Core\Field\FormatterBase;
use Drupal\Core\Field\FieldItemListInterface;

/**
 * Plugin implementation of the 'ROTEncoder' formatter.
 *
 * @FieldFormatter(
 *   id = "customfield_rotencoder",
 *   label = @Translation("ROT Encoder Formatter"),
 *   field_types = {
 *     "text",
 *     "text_long",
 *     "text_with_summary"
 *   }
 * )
 */
class ROTEncoder extends FormatterBase { 
/**
* {@inheritdoc}
*/    
    private function ROT13Encoder($data) {
        $ROT13 = array();
        for ($i = 0, $j = strlen($data); $i < $j; $i++) {
            // Get the ASCII character for the current character
            $char = ord( $data[$i]); 

            // If that character is in the range A-Z or a-z, add 13 to its ASCII value
            if( ($char >= 65  && $char <= 90) || ($char >= 97 && $char <= 122)) 
            {
                $char += 13; 

                // If we should have wrapped around the alphabet, subtract 26
                if( $char > 122 || ( $char > 90 && ord( $data[$i]) <= 90)) 
                {
                    $char -= 26;
                }
            }
            $ROT13[] = chr( $char);

        }      
        return implode($ROT13);
    }

    
/**
* {@inheritdoc}
*/
    public function viewElements(FieldItemListInterface $items, $langcode) {
        $element = array();

        foreach ($items as $delta => $item) {
          // Render each element as markup.
          $element[$delta] = array(
            '#type' => 'markup',
            '#markup' => $this->ROT13Encoder($item->value),
          );
        }

        return $element;
   }
}