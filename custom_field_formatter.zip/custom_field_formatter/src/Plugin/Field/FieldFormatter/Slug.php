<?php

/**
 * @file
 * 
 * Contains \Drupal\custom_field_formatter\Plugin\Field\FieldFormatter\Slug.
 */

namespace Drupal\custom_field_formatter\Plugin\Field\FieldFormatter;

use Drupal\Core\Field\FormatterBase;
use Drupal\Core\Field\FieldItemListInterface;

/**
 * Plugin implementation of the 'Slug' formatter.
 *
 * @FieldFormatter(
 *   id = "customfield_slug",
 *   label = @Translation("Slug Formatter"),
 *   field_types = {
 *     "text",
 *     "text_long",
 *     "text_with_summary"
 *   }
 * )
 */
class Slug extends FormatterBase { 
/**
* {@inheritdoc}
*/    
    private function Slug($data) {    
        $service = \Drupal::service('custom_field_formatter.slugify');
        $config  = \Drupal::config('custom_field_formatter.settings');
        return $service->slugify($data, $config->get('slugify')); 
    }

/**
* {@inheritdoc}
*/
    public function viewElements(FieldItemListInterface $items, $langcode) {
        $element = array();

        foreach ($items as $delta => $item) {
          // Render each element as markup.
          $element[$delta] = array(
            '#type' => 'markup',
            '#markup' => $this->Slug($item->value),
          );
        }

        return $element;
   }
}